# Dieses Skript erstellt eine Übersicht über alle annotierten Futurbelege aus der Vulgata mitsamt der entsprechenden 
# - Konstruktion, 
# - der vorliegenden Form,
# - und der ganzen Zeiele,
# jeweils aus den drei verglichenen mnd. Bibeln.


library(writexl)
library(readxl)
library(tidyverse)
library(stringr)


# Den Pfad des aktuellen R-Skripts einstellen:
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

DF <- read_excel("../qualitativ/7_Passivbelege/Futurbelege_PASSIV_Vulgata_Gesamt2023-08-18.xlsx",
                 col_types = "text")



# erstelle Übersicht über alle annotierten futurischen Stellen in der Vulgata (Jede ID in Futurbeleg ist 3 mal enthalten)
OV_Bibelstellen <- DF %>% 
  group_by(ID_passiv, Bibel, Zeilen, Form) %>% 
  count() %>% 
  select(-n) %>% 
  arrange(-desc(as.numeric(ID_passiv)))




# extrahiert die Zeilen
zeilen <- OV_Bibelstellen %>% 
  ungroup() %>% 
  select(-Form) %>% 
  pivot_wider(names_from = Bibel, names_prefix = "zeilen_", values_from = Zeilen)


# extrahiert die Formen
formen <- OV_Bibelstellen %>% 
  ungroup() %>% 
  select(-Zeilen) %>% 
  pivot_wider(names_from = Bibel, names_prefix = "form_", values_from = Form)

# Stellt die Entsprechungen der cx zusammen
Entsprechungen <- DF %>%
  filter(skiprow_fut == "FUTUR_Passiv") %>% 
  #filter(cx != "-") %>% 
  group_by(ID_passiv, Bibel, cx) %>% 
  count() %>%
  pivot_wider(names_from = Bibel, names_prefix = "cx_", values_from = cx) %>% 
  select(-n) %>% 
  arrange(-desc(as.numeric(ID_passiv)))

# Führt alles zusammen in ein Dataframe
test <- left_join(Entsprechungen,zeilen)
test <- left_join(test, formen, by= "ID_passiv")

# Spaltenreihenfolge festlegen
test <- test[c("ID_passiv",
               "cx_HBS",
               "cx_KLN",
               "cx_LBK",
               "zeilen_HBS",
               "form_HBS",
               "zeilen_KLN",
               "form_KLN",
               "zeilen_LBK", 
               "form_LBK")]


#speichern unter aktuellem Datum

write_xlsx(test, paste0('../qualitativ/7_Passivbelege/Uebersicht_Bibelstellen_PASSIV',Sys.Date(),'.xlsx'))

