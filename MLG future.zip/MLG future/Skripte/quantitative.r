library(writexl)
library(readxl)
library(tidyverse)
library(stringr)

# Den Pfad des aktuellen R-Skripts einstellen: 
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
# Plots speichern (einmal den path festlegen)
path<-"../quantitativ/Abbildungen/"



# Die Gesamtdatei laden -------------------------------
# werden + infinitiv
DF <- read_excel("../quantitativ/werden+Infinitiv_werden+Partizip/LS_SI_merge2023-09-07.xlsx",
                 col_types = "text")
INF <- DF %>%
  filter(Aufsatz_FoP == "yes") %>% 
  filter(str_detect(Slotverb_pos, "INF")) %>% 
  filter(structure == "pres_ind")

# werden + partizip

VVPS <-  DF %>% 
  filter(Aufsatz_FoP == "yes") %>%
  filter(str_detect(Slotverb_pos, "VVPS")) %>% 
  filter(structure == "pres_ind")

# Modals: schölen und willen
# Modals<- read_excel("../quantitativ/finite_modals_per_text_ren.xlsx",
#                    col_types = "text")
# Modals <- Modals %>% 
#   rename(nFiniteModals = count)

# lade Metadatentabelle ---------------------------------------
REN <- read_excel("../quantitativ/Textübersicht_REN.xlsx",
           col_types = "text")
VFINfreq <- read_excel("../quantitativ/finite_verbs_per_text_ren.xlsx",
                       col_types = "text")
VFINfreq <- VFINfreq %>% 
  rename(nVerbs = count)
REN <- left_join(REN, VFINfreq)
#REN <- left_join(REN, Modals)

# Summe finiter Verben pro timeslot 
time_verbs<- aggregate(as.numeric(nVerbs) ~ time2, REN, sum)
time_verbs<- time_verbs %>% rename(nVerbs = "as.numeric(nVerbs)")

# Summe finiter Modals pro timeslot
#time_modals <-aggregate(as.numeric(nFiniteModals) ~ time2, REN, sum)
# time_modals<- time_modals %>% rename(time =time2, 
#                                      nModals = "as.numeric(nFiniteModals)")

# diachronen Verlauf plotten (normalisiert nach Anzahl finiter Verbformen im Korpus)---------------

timeadd <- REN %>% 
  select(meta_abbr_ddd, time2, meta_language_area) %>% 
  rename(abbr_ddd = meta_abbr_ddd)

INF <- left_join(INF, timeadd, by = "abbr_ddd")

  
VVPS <- left_join(VVPS, timeadd, by = "abbr_ddd")

time_inf<-INF %>% 
  #group_by(abbr_ddd) %>% 
  group_by(time2) %>% 
  count() %>% 
  rename(n_INF = n)

time_vps<-VVPS %>%
  group_by(time2) %>% 
  count() %>% 
  rename(n_vps = n)

time_inf_vps <- left_join(time_inf, time_vps)
time_inf_vps <- left_join(time_inf_vps, time_verbs)
#time_inf_vps <- left_join(time_inf_vps, time_modals)

# inf_part_diach <- 
time_inf_vps %>%
  ggplot()+
  aes(x=time2)+
  geom_point(aes(y=(n_vps/nVerbs)*1000),colour = "#00BFC4")+
  geom_point(aes(y = (n_INF/nVerbs)*1000),colour = "#F8766D")+
  #geom_point(aes(y = (nModals/nVerbs)*1000),colour = "#f37e12")+
  theme_classic()+
  labs(y = "number per 1000 finite verbs")+
  theme(legend.title = element_blank(), legend.position = "top")+
  scale_colour_discrete(labels= c(sprintf('w\u0113rden + present participle'),
                             sprintf('w\u0113rden + infinitive')))+
  NULL



######## Neuer Anlauf, sinnvolle Datenstruktur und ordentliche Abbildung:

test <- time_inf_vps %>% 
  replace(is.na(.), 0) %>% 
  mutate(vps_perc = (n_vps/nVerbs)*1000) %>% 
  mutate(inf_perc = (n_INF/nVerbs)*1000) %>% 
  select(time2, vps_perc, inf_perc) %>% 
  pivot_longer(
    cols = c("vps_perc","inf_perc"),
    names_to = "Construction",
    #names_prefix = "cx",
    values_to = "Value",
    values_drop_na = TRUE)

# half_cents_new <- 
test %>% 
  mutate(Construction = fct_relevel(Construction, "vps_perc", "inf_per")) %>%
  ggplot()+
  aes(x=time2, y = Value, fill = Construction)+
  geom_bar(position="dodge", stat="identity")+
  theme_classic()+
  labs(y = "Frequency per 1000 finite verbs", 
       x = "Half Centuries")+
  theme(legend.title = element_blank(), legend.position = "top")+
  scale_fill_discrete(labels= c(sprintf('w\u0113rden + present participle'), 
                                sprintf('w\u0113rden + infinitive')))+
  NULL
  

ggsave(filename = paste0("freqren_halfcents.png"), 
       plot = half_cents_new,
       width = 150, 
       height = 100,
       units = "mm", 
       dpi = 500)

# write_xlsx(time_inf_vps, "time_inf_vps.xlsx")


#### hier wieder altes skript

vfin_diach<- time_inf_vps %>%
  ggplot()+
  aes(x=time2)+
  geom_point(aes(y= nVerbs))+
  theme_classic()+
  labs(y = "number of finite verbs")

ggsave(filename = paste0(path,"Abbildung2.png"), 
       plot = vfin_diach,
       width = 150, 
       height = 100,
       units = "mm", 
       dpi = 500)

# noch mal per 10 000 token, und century wise


#Inf counts in die übersicht!
INF_counts <- INF %>% 
  group_by(abbr_ddd) %>% 
  count() %>% 
  rename(nwerdenInf = n, 
         meta_abbr_ddd = abbr_ddd)
REN <- left_join(REN, INF_counts)
#PS counts in die übersicht!
VVPS_counts <- VVPS %>%
  group_by(abbr_ddd) %>% 
  count() %>% 
  rename(nwerdenPart= n, 
                meta_abbr_ddd = abbr_ddd)
REN <- left_join(REN, VVPS_counts)


# aggregate counts per century
 cent_counts <- aggregate(as.numeric(nwerdenInf) ~ century, REN, sum)
 cent_counts <- cent_counts %>% 
   rename(nWerdenInf= "as.numeric(nwerdenInf)")
 plus <- aggregate(as.numeric(nwerdenPart) ~ century, REN, sum)
 
 cent_counts<-  left_join(cent_counts, plus)
 cent_counts <- cent_counts %>% 
   rename(nWerdenPart= "as.numeric(nwerdenPart)")
 
token_counts <- aggregate(as.numeric(TokenCount) ~ century, REN, sum)
cent_counts<-  left_join(cent_counts, token_counts)
cent_counts <- cent_counts %>% 
  rename(TokenCount= "as.numeric(TokenCount)")

modal_counts <- aggregate(as.numeric(nFiniteModals) ~ century, REN, sum)
cent_counts<-  left_join(cent_counts, modal_counts)
cent_counts <- cent_counts %>% 
  rename(nFiniteModals= "as.numeric(nFiniteModals)")


HGComp <-
  cent_counts %>%
   ggplot()+
  aes(x=century)+
  geom_line(aes(y=(nWerdenPart/TokenCount)*10000,group=1, colour = "#00BFC4"), linewidth =1.3)+
  geom_line(aes(y = (nWerdenInf/TokenCount)*10000,group=1, colour = "#F8766D"), linewidth =1.3)+
   #geom_point(aes(y = (nModals/nVerbs)*1000),colour = "#f37e12")+
   theme_classic()+
   labs(y = "Frequency per 10,000 words", 
        title = "REN")+
  theme(#plot.title = element_text(hjust = 0.5), 
      plot.title = element_blank(),
      legend.title = element_blank(),
      legend.position = "top")+
  scale_colour_discrete(labels= c("werden+part", "werden+inf"))
 
 ggsave(filename = paste0(path,"Abbildung3.png"), 
        plot = HGComp,
        width = 150, 
        height = 100,
        units = "mm", 
        dpi = 500)
 
 write_xlsx(cent_counts, '../quantitativ/counts_per_century.xlsx')
 
 
