library(writexl)
library(readxl)
library(tidyverse)
library(stringr)


# Den Pfad des aktuellen R-Skripts einstellen:
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))


# Das Datenset einlesen
DF <- read_excel("../qualitativ/4_annotationsdatei/Abgleich_Vulgata_Lukas2.xlsx",
                 col_types = "text")

# mögliche Futur2 Endungen identifizieren
DF <- DF %>% 
  mutate(x = case_when(endsWith(Token_clean, "ero")~ "yes", 
                            endsWith(Token_clean, "eris")~ "yes", 
                            endsWith(Token_clean, "erit")~ "yes", 
                            endsWith(Token_clean, "erimus")~ "yes", 
                            endsWith(Token_clean, "eritis")~ "yes", 
                            endsWith(Token_clean, "erint")~ "yes"))

# Liste  der möglichen FUTUR2 Belege erstellen
a <- DF %>% 
  filter(Futur == "FUTUR") %>% 
  group_by(pot_Futur2, Token_clean) %>% 
  count() %>% 
  filter(pot_Futur2 == "yes")

# Dateneset und Belegtabelle werden in Exceldateien geschrieben (mit aktuellem Datum im Dateinamen)

write_xlsx(DF, paste0('../Weitere Bücher  zur Annotation/Abgleich_Vulgata_Bergpredigt',Sys.Date(),'.xlsx'))
write_xlsx(a, paste0('..//Weitere Bücher  zur Annotation/Bergpredigt_PotentiellFutur2',Sys.Date(),'.xlsx'))


