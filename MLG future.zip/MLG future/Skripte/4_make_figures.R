# ---
# title:  futures of the past - figures Chapter 4.2
# author: Lena Schnee (lena.schnee@hhu.de)
# date:   
# description: This script creates the figures used in section 4.2.
#              In order to make it work, please make sure to provide 
#              the correct pathway to access the two data sets.    
#---


# preliminaries: ---------------------------------------------------------------
# load packages (install if necessary)
library(writexl)
library(readxl)
library(tidyverse)
library(stringr)

# Den Pfad des aktuellen R-Skripts einstellen:
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))

# Die Gesamtdatei laden
df <- read_excel("../qualitativ/4_annotationsdatei/Abgleich_Vulgata_Gesamt2023-09-13.xlsx",
                 col_types = "text")
# Die reduzierte Datei mit den Futurbelegen laden
DF <- read_excel("../qualitativ/5_analysedatei_futurbelege/Futurbelege_Vulgata_Gesamt2024-09-11.xlsx",
                 col_types = "text")


# jeweils nur noch die tatsächlichen lat. Futurbelege auswählen (filtert Futur 2 und ambige Fälle raus)
df <- df %>% 
  filter(Futur == "FUTUR")
DF <- DF %>% 
  filter(!is.na(FUT_ID_finalst))

DF$cx<- as.character(DF$cx)
DF$cx[DF$cx == 'pres'] <- "present"
DF$cx[DF$cx == 'imp'] <- "imperative"
DF$cx<- factor(DF$cx)

# Factor levels Reihenfolge Bibeln
DF <- DF %>% 
  mutate(Bibel = fct_relevel(Bibel,
                             "KLN",
                             "LBK",
                             "HBS")) %>%
  mutate(cx = fct_relevel(cx,"present",
                          "werden+inf",
                          "werden+werden+inf",
                          "werden+part1",
                       
                          "schölen+werden+part1", 
                    
                          "schölen+inf", 
                          "schölen+part1", 
                          "willen+inf", 
                          "imperative",
                          "-"))

# define theme 

theme_lena <- 
  theme_classic() + 
  theme(
    # position and font style of the legend
    legend.position = "bottom",
    legend.title = element_text(size = 20, face = "bold"),
    legend.text = element_text(size = 14),
    legend.key.height = unit(0.5,"line"),
    legend.key.width =  unit(0.5,"line"), 
    
   
    #legend.background = element_rect(fill = "transparent"),
    # style of the strip background when we use the facet command
    strip.background = element_blank(),
    
    # distance between facet panels
    panel.spacing = unit(2, "lines"),
    strip.text.x = element_text(size = 14),
    # font style of your axes and titles
    axis.text = element_text(size = 20),
    axis.title = element_text(size = 24, face = "bold"),
    plot.title = element_text(size = 30, face = "bold",hjust = 0.5),
    # margins (white space) around your plot
    plot.margin = unit(c(1.5,1.5,1.5,1.5),"cm"),
    panel.grid.major.y = element_line(colour = "grey50"),
    # make the plot background transparent so if you insert it into your slides it merges with your slide deck
    #plot.background = element_rect(fill = "transparent", colour = NA),
    # panel.background = element_rect(fill = "transparent")
  ) 



# FIG : Allg Übersicht Daten ------------------------------------------

farben  <- c("#8f6dc0", #present
             "#1f78b4", #werden+inf
             "#42c5f5", #werden+werden+inf 
             "#b2df8a", #werden+part1
             "#98d463", #schölen+werden+part1
             "#fdc086", #schölen#inf
             "#fc983b", #schölen+part1 
             "#f37e12", #willen+infinitive
             "#ffffb3"  #imperative
             )

# abb1 <-
DF %>%
  filter(cx != "-") %>% 
  filter(skiprow_fut == "FUTUR") %>% 
  ggplot()+
  aes(x= Bibel, fill = cx, label = scales::percent(prop.table(stat(count))))+
  geom_bar()+
  # geom_text(stat = 'count',
  #           #position = position_dodge(.5), 
  #           vjust = 0.5, 
  #           size = 3)+
  scale_fill_manual(values = farben, labels = c("present",
                                                sprintf('w\u0113rden + infinitive'),
                                                sprintf('w\u0113rden + w\u0113rden + infinitive'),
                                                sprintf('w\u0113rden + present participle'),
                                                sprintf("schȫlen + w\u0113rden + present participle"),
                                                "schȫlen + infinitive",
                                                "schȫlen + present participle",
                                                "willen + infinitive",
                                                "imperative"))+

  labs(y = "Frequency", fill = "", x = "")+
  scale_x_discrete(labels=c("Köln \n 1478/79", "Lübeck \n 1494", "Halberstadt \n 1522"))+
  #scale_y_continuous(breaks = seq(10, 150, by = 10))+
  #facet_wrap(~Bibel, ncol = 3)+
  #theme(legend.position = "bottom")+
  theme_classic()+
  NULL

path<-"../../Aufsatz/Abbildungen_neu/"
ggsave(filename = paste0(path,"Abb4.png"),
       plot = abb1,
       width = 150,
       height = 100,
       units = "mm",
       dpi = 500)


# FIG  XX : Übersicht alle Stellen --------------


farben  <- c(
  "#8f6dc0", #present
            "#1f78b4", #werden+inf
            "#42c5f5",#werden+werden+inf 
            "#b2df8a", #werden+part1
            "#98d463", #schölen+werden+part1
            "#fdc086", #schölen+inf
            "#fc983b", #schölen+part1
  
            "#f37e12", #willen+inf
            "#ffffb3"  #imperative
            
          
  ) 
           
#biblenames <- as_labeller(c('KLN' = "Köln \n 1478/79", 'LBK' = "Lübeck \n 1494", 'HBS' ="Halberstadt \n 1522"))

biblenames <- as_labeller(c('KLN' = "Köln 1478/79", 'LBK' = "Lübeck 1494", 'HBS' ="Halberstadt 1522"))
labels <- c("1" = "Gen.2",
            "3" = "Gen.3", 
            "11" = "Gen.4",
            "19" = "Gen.11",
            "20" = "Gen.22",
            "24" = "Exod. 20",
            "45" = "Luke 2",
            "47" = "Mt. 5",
            "64" = "Mt. 6",
            "84" = "Mt. 7")

labelsl <- c("1" = "Gen.2",
             "3" = "",
             "11" = "Gen.4",
             "19" = "",
             "20" = "Gen.22",
            "24" = "Exod. 20",
             "45" = "",
             "47" = "Mt. 5",
             "64" = "Mt. 6",
            "84" = "Mt. 7")
labelsr <- c(
             "3" = "Gen.3", 
         
             "19" = "Gen.11",
             "45" = "Luke 2")

             


abb <-DF %>%
  ungroup() %>%
  #filter(fut_checked == "FUTUR") %>% 
  # mutate(cx = fct_relevel(cx,
  #                         "present",
  #                         "werden+inf",
  #                         "werden+part1",
  #                         "schölen+werden+part1",
  #                         "schölen+inf",
  #                         "willen+inf",
  #                         "imperative")) %>%
  
  filter(cx != "-" 
         & cx != "hebben+part2"
         #& cx != "schölen+part1"
         & cx != "werden+part2"
         & cx != "schölen+werden+part2") %>% 
  ggplot()+
  aes(x = as.numeric(FUT_ID_finalst) ,fill= cx)+
  geom_bar(stat = "count")+
  guides(fill = guide_legend(nrow = 3))+
  
  scale_fill_manual(values = farben, labels = c("present",
                                                sprintf('w\u0113rden + infinitive'),
                                                sprintf('w\u0113rden + w\u0113rden + infinitive'),
                                                sprintf('w\u0113rden + present participle'),
                                                sprintf("schȫlen + w\u0113rden + present participle"),
                                                "schȫlen + infinitive",
                                                "schȫlen + present participle",
                                    
                                                "willen + infinitive",
                                                "imperative"))+
  
  #scale_x_continuous(breaks = seq(0, 100, by = 10), sec.axis = dup_axis(breaks = seq(5, 95, by = 10), name = ""))+
  #scale_x_continuous(breaks = seq(0, 100, by = 5))+
  #scale_x_continuous(label = labels)+
  scale_x_continuous(breaks = c(1, 3, 11, 19, 20, 24, 45, 47, 64, 84), 
                     label = labelsl, 
                     name = "", 
                     sec.axis = dup_axis(breaks =  c( 3,  19, 45), 
                                         label = labelsr, name = ""))+
  #scale_x_discrete(labels=c("Köln \n 1478/79", "Lübeck \n 1494", "Halberstadt \n 1522"))+
  #stat_count(geom = "text", colour = "white", size = 3.5,position=position_stack(vjust=0.5))+
  #expand_limits(x= c(-1, 80))+
  #geom_text(aes(label = lemma_vollverb), stat = "identity")+
  coord_flip()+
  facet_wrap(vars(Bibel), labeller = biblenames)+
  theme_classic()+
  labs(x = "Bible Passage")+
  theme_lena+
  theme(axis.text.x = element_blank(),
        axis.ticks =element_blank(),
        axis.title.x = element_blank(), 
        legend.position = "bottom",
        legend.text = element_text(size = 13),
        #legend.position = "right", 
        #legend.justification='bottom',
        legend.title = element_blank(),
        axis.line.x = element_blank(),
        axis.text = element_text(size = 14),
        plot.margin = unit(c(0.5,0.5,0.5,0.5),"cm"))+
  #guides(fill = guide_legend(ncol = 4))
  guides(fill = guide_legend(override.aes = list(size=4), nrow = 3, byrow = TRUE))
  

ggsave(filename = paste0("Abb6_labels_new.png"), 
       plot = abb,
       width = 300, 
       height = 190,
       units = "mm", 
       dpi = 500)




# FIG 9: Constructions * Person&Number wrapped per Bible ------------------------
person_cx <-DF %>%
  filter(cx !="-") %>%
  #filter(persNum_fin %notin% c("-", "?", "0")) %>% 
  ggplot()+
  aes(x= fct_rev(fct_infreq(persNum_fin)), fill = cx)+
  geom_bar()+
  scale_fill_manual(values = c("present"=	"#8f6dc0",
                               "imperative"	= "#ffffb3",
                               "werden+inf" =	"#1f78b4",
                               "werden+werden+inf" = "#419fde",
                               "werden+part1"=	"#b2df8a",
                               "schölen+werden+part1"=	"#98d463",
                               "schölen+inf"	= "#fdc086",
                               "schölen+part1"="#fc983b",
                               "willen+inf"=	"#f37e12"), 
                    labels = c("present",
                               sprintf('w\u0113rden + infinitive'),
                               sprintf('w\u0113rden + w\u0113rden + infinitive'),
                               sprintf('w\u0113rden + present participle'),
                               sprintf("schȫlen + w\u0113rden + present participle"),
                               "schȫlen + infinitive",
                               "schȫlen + present participle",
                               "willen + infinitive",
                               "imperative"))+
  coord_flip()+
  scale_y_continuous(breaks = seq(0, 30, by = 15))+
  labs(x = "Person - Number", y = "", fill ="")+
  facet_wrap(~Bibel, labeller = biblenames)+
  theme_lena+
  theme(strip.text.x = element_text(size = 15),
        # font style of your axes and titles
        axis.text = element_text(size = 11),
        axis.title = element_text(size = 13, face = "bold"),
        plot.title = element_text(size = 13, face = "bold",hjust = 0.5),
        legend.text = element_text(size = 10)
        )+
        # margins (white space) around your plot)+
  guides(fill = guide_legend( nrow = 3, byrow = TRUE))


path = ""
ggsave(filename = paste0(path,"person_construction_biblewrap1.png"), 
       plot = person_cx,
       width = 200, 
       height = 150,
       units = "mm", 
       dpi = 300)

# ragg::agg_png("ragg_text.png", width = 200, height = 200, units = "in", res = 300, scaling = 0.5)
# person_cx
# dev.off()
# 

# FIG XX: Sentence semantcs $ construction

biblenames <- as_labeller(c('KLN' = "Köln\n 1478/79", 'LBK' = "Lübeck\n 1494", 'HBS' ="Halberstadt\n 1522"))

# satztyp_cx <- 
DF %>%
  filter(!grepl("/", Satzsemantik)) %>%
  filter(cx != "-") %>% 
  ggplot()+
  aes(x = fct_rev(fct_infreq(Satzsemantik)), fill = cx) +
  geom_bar() +
  coord_flip()+
  scale_fill_manual(values = c("present"=	"#8f6dc0",
                               "imperative"	= "#ffffb3",
                               "werden+inf" =	"#1f78b4",
                               "werden+werden+inf" = "#419fde",
                               "werden+part1"=	"#b2df8a",
                               "schölen+werden+part1"=	"#98d463",
                               "schölen+inf"	= "#fdc086",
                               "schölen+part1"="#fc983b",
                               "willen+inf"=	"#f37e12"),
                    labels = c("present",
                               sprintf('w\u0113rden + infinitive'),
                               sprintf('w\u0113rden + w\u0113rden + infinitive'),
                               sprintf('w\u0113rden + present participle'),
                               sprintf("schȫlen + w\u0113rden + present participle"),
                               "schȫlen + infinitive",
                               "schȫlen + present participle",
                               "willen + infinitive",
                               "imperative"))+
  # facet_wrap(~Bibel)+
  facet_wrap(vars(Bibel), labeller = biblenames)+
  theme_lena+
  labs(x="Sentence Semantics", fill = "Construction")+
  theme(legend.title = element_blank(),
        legend.position = "bottom",
        legend.text = element_text(size =10),
        legend.key.size = unit(0.25, 'cm'),
        
        axis.title = element_text(size=10),
        axis.text= element_text(size = 10),
        
        panel.grid.major.x =element_line(colour = "grey80"),
        strip.text.x = element_text(size = 10),
        plot.margin = unit(c(0.5,0.5,0.5,0.5),"cm"))+
  scale_x_discrete(labels=c("habitual" = "habitual action", "generic" = "generic statement"))+
  guides(fill = guide_legend(override.aes = list(size=2), ncol = 4, byrow = TRUE))+
  
  NULL

# Plots speichern Speichern (einmal den path festlegen)
path <- "../../Aufsatz/Abbildungen_neu/"

ggsave(filename = paste0(path,"satztyp_cx_new_abs.png"), 
       plot = satztyp_cx,
       width = 200, 
       height = 100,
       units = "mm", 
       dpi = 700)
