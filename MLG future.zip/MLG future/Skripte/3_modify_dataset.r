library(writexl)
library(readxl)
library(tidyverse)
library(stringr)


# Den Pfad des aktuellen R-Skripts einstellen:
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))


# # Die zu mergenden Dateien einlesen
# DF1<- read_excel("../Abgleich_Vulgata/Abgleich_Vulgata_Genesis_Halberstadt_Lübeck_Köln2023-02-23.xlsx", 
#                  col_types = "text")
# 
# DF1<- DF1 %>% 
#   mutate(Annotation = sub('.', '',Annotation))%>% 
#   mutate(Book = "Genesis")
# 
# DF2 <-read_excel("../Abgleich_Vulgata/Abgleich_Vulgata_Exodus_Halberstadt_Lübeck_Köln2023-02-23.xlsx", 
#                   col_types = "text")
# DF2<- DF2 %>% 
#   mutate(Annotation = sub('.', '',Annotation))%>% 
#   mutate(Book = "Exodus")
# 
# DF <- rbind(DF1, DF2)
# rm(DF1, DF2)
# 
# 
# # make one Dataset with all comparable chapters
# DF_reduced <- DF %>% 
#   filter(Kapitel != "AUSLASSUNG_REN")

# Schreiben einer neuen Exceldatei mit aktuellem Datum im Dateinamen
# # Aktuelles Datum
# today <- str_split_fixed(Sys.time(), " ", n = 2)
# today <- today
# write_xlsx(DF_reduced, paste0('Abgleich_Genesis_Exodus',today,'.xlsx'))
# 
# 


#read in 'Abgleich_Genesis_Exodus',today,'.xlsx', then perform the rest of the script on it


DF <- read_excel("../qualitativ/4_annotationsdatei/Abgleich_Vulgata_Gesamt2023-09-13.xlsx", 
                            col_types = "text")


# filtern: nur eindeutige Futur1 Belege, präsens indikativ aktiv
DF_fut <- DF %>% 
  filter(!is.na(FUT_ID_finalst))
  
colnames(DF_fut)
# pivot longer for all annos:
test <- DF_fut %>% 
  pivot_longer(c(Form_HBS, Form_KLN, Form_LBK), 
               names_to = "Form_Bibel", 
               values_to = "Form")

n_last <- 3                                # Specify number of characters to extract
test <- test %>%
  mutate(Bibel = substr(Form_Bibel, nchar(Form_Bibel) - n_last + 1, nchar(Form_Bibel))) #%>%
  # select(-Bibel2)
test <- test %>% 
  mutate(newID = paste0(FUT_ID_final, Bibel))

test <- test %>% 
  pivot_longer(c(cx_HBS, cx_KLN, cx_LBK),  
               names_to = "cx_Bibel", 
               values_to = "cx")


test <- test %>% 
  pivot_longer(c(lemma_vollverb_HBS, lemma_vollverb_KLN, lemma_vollverb_LBK), 
               names_to = "lemma_vollverb_Bibel", 
               values_to = "lemma_vollverb") 

test <- test %>% 
  pivot_longer(c(temp_fin_HBS, temp_fin_KLN, temp_fin_LBK), 
               names_to = "temp_fin_Bibel", 
               values_to = "temp_fin") 


test <- test %>% 
  pivot_longer(c(modus_fin_HBS, modus_fin_KLN, modus_fin_LBK), 
               names_to = "modus_fin_Bibel", 
               values_to = "modus_fin") 

test <- test %>% 
  pivot_longer(c(persNum_fin_HBS, persNum_fin_KLN, persNum_fin_LBK), 
               names_to = "persNum_fin_Bibel", 
               values_to = "persNum_fin") 


test <- test %>% 
  pivot_longer(c(ZeilenNr_HBS, ZeilenNr_KLN, ZeilenNr_LBK), 
               names_to = "ZeilenNr_Bibel", 
               values_to = "ZeilenNr") 

test <- test %>% 
  pivot_longer(c(Zeilen_HBS, Zeilen_KLN, Zeilen_LBK), 
               names_to = "Zeilen_Bibel", 
               values_to = "Zeilen") 

test <- test %>% 
  pivot_longer(c(Kommentar_HBS, Kommentar_KLN, Kommentar_LBK), 
               names_to = "Kommentar_Bibel", 
               values_to = "Kommentar") 

# deduplicate

HBS <- test %>% 
  filter(Form_Bibel == "Form_HBS" & 
           cx_Bibel == "cx_HBS" & 
           lemma_vollverb_Bibel == "lemma_vollverb_HBS" &
           temp_fin_Bibel == "temp_fin_HBS" &
           modus_fin_Bibel == "modus_fin_HBS" & 
           persNum_fin_Bibel == "persNum_fin_HBS" &
           ZeilenNr_Bibel == "ZeilenNr_HBS"& 
           Zeilen_Bibel == "Zeilen_HBS"&
           Kommentar_Bibel == "Kommentar_HBS"& 
           str_detect(newID, "HBS"))


KLN <- test %>%
  filter(Form_Bibel == "Form_KLN" & 
           cx_Bibel == "cx_KLN" & 
           lemma_vollverb_Bibel == "lemma_vollverb_KLN" &
           temp_fin_Bibel == "temp_fin_KLN" &
           modus_fin_Bibel == "modus_fin_KLN" & 
           persNum_fin_Bibel == "persNum_fin_KLN" &
           ZeilenNr_Bibel == "ZeilenNr_KLN"& 
           Zeilen_Bibel == "Zeilen_KLN"&
           Kommentar_Bibel == "Kommentar_KLN"& 
           str_detect(newID, "KLN"))
LBK <- test %>%
  filter(Form_Bibel == "Form_LBK" & 
           cx_Bibel == "cx_LBK" & 
           lemma_vollverb_Bibel == "lemma_vollverb_LBK" &
           temp_fin_Bibel == "temp_fin_LBK" &
           modus_fin_Bibel == "modus_fin_LBK" & 
           persNum_fin_Bibel == "persNum_fin_LBK" &
           ZeilenNr_Bibel == "ZeilenNr_LBK"& 
           Zeilen_Bibel == "Zeilen_LBK"&
           Kommentar_Bibel == "Kommentar_LBK"& 
           str_detect(newID, "LBK"))

DF_fut_final <- rbind(HBS,KLN)  
DF_fut_final <- rbind(DF_fut_final, LBK)
colnames(DF_fut_final)
rm(test)

# todo: spalten löschen, spaltenreihenfolge, morph lat

DF_fut_final  <- DF_fut_final %>% 
  select(-c("Token",
            "Form_Bibel",
            "cx_Bibel",
            "lemma_vollverb_Bibel",
            "temp_fin_Bibel",
            "modus_fin_Bibel",
            "persNum_fin_Bibel",
            "ZeilenNr_Bibel",
            "Zeilen_Bibel",
            "Kommentar_Bibel"))

DF_fut_final  <- DF_fut_final %>% 
  mutate(active_passive = case_when(str_detect(MorphAnno, "active") ~"ACTIVE", TRUE ~ "PASSIVE")) %>% 
  mutate(Modus = case_when(str_detect(MorphAnno, "indicative")~"INDICATIVE")) %>% 
  mutate(Numerus= case_when(str_detect(MorphAnno, "singular")~ "SINGULAR", TRUE ~"PLURAL")) %>% 
  mutate(Person = case_when(str_detect(MorphAnno, "1")~"1", 
                            str_detect(MorphAnno, "2")~"2", 
                            str_detect(MorphAnno, "3")~"3"))



DF_fut_final <- DF_fut_final[c("ID",
                               "FUT_ID_finalst",
                               "Buch",
                               "Kapitel",
                               "Abbr",
                               "Kap_ID",
                               "Satz_ID",
                               "Kapitel_Satz_ID",
                               "Testament_Kapitel_Satz",
                               "Testament_Buch_Kapitel_Satz",
                               "Satz",
                               "Satz ESV",
                               "Token_clean",
                               "Lemma",
                               "Translation",
                               "Futur",
                               "skiprow_fut",
                               "Deponens?",
                               "pot_Futur2",
                               "Kommentar_pos_lat",
                               "Satzsemantik",
                               "Satztyp",
                               "Satztyp_spezifiziert",
                               "Aktionsart",
                               "Negation",
                               "Frage",
                               
                               "EntsprPart1LBK",
                               "EntsprWerdInfHBS",
                               "EntsprPresHBS",
                               "EntsprScholInfKLN",
                               
                               "Form",
                               "Bibel",
                               "newID",
                               "cx",
                               
                               "lemma_vollverb",
                               "temp_fin",
                               "modus_fin",
                               "persNum_fin",
                               
                               "ZeilenNr",
                               "Zeilen",
                               "Kommentar",
                               "active_passive",
                               
                               "Modus",
                               "Numerus",
                               "Person")]


# Schreiben einer neuen Exceldatei mit aktuellem Datum im Dateinamen
# Aktuelles Datum

write_xlsx(DF_fut_final, paste0('../qualitativ/5_analysedatei_futurbelege/Futurbelege_Vulgata_Gesamt', Sys.Date(),'.xlsx'))
#write_xlsx(DF_fut_final, paste0('Futurbelege_Vulgata_Gesamt', Sys.Date(),'_1.xlsx'))



